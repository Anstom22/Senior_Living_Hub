import seniorLivingStore from "./Reducers/navigationReducer";

const rootReducer: any = { seniorLivingStore };
export default rootReducer;
