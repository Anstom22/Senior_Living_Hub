const AllergiesList = [
    { label: 'Peanuts', value: 'peanuts' },
    { label: 'Shellfish', value: 'shellfish' },
    { label: 'Dairy', value: 'dairy' },
    { label: 'Eggs', value: 'eggs' },
    { label: 'Gluten', value: 'gluten' },
    { label: 'Soy', value: 'soy' },
    { label: 'Tree Nuts', value: 'tree-nuts' },
    { label: 'Fish', value: 'fish' },
    { label: 'Wheat', value: 'wheat' },
    { label: 'Sesame', value: 'sesame' },
    { label: 'Milk', value: 'milk' },
    { label: 'Mustard', value: 'mustard' },
    { label: 'Sulfites', value: 'sulfites' },
    { label: 'Corn', value: 'corn' },
    { label: 'Caffeine', value: 'caffeine' },
    // Add more allergies as needed
  ];
  
  export default AllergiesList;
  