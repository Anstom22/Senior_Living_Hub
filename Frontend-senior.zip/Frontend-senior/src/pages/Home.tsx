import Information from "../component/Information";

const Home = () => {
  return <Information />
};

export default Home;
